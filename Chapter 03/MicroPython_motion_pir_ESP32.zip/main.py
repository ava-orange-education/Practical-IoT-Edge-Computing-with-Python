from machine import Pin
import utime
from utime import sleep

print("Hello, ESP32!")

# Constants for pin and state
SENSOR_PIN = 19  # The ESP32 pin GPIO19 connected to the HC-SR501 motion sensor

# Setup the motion sensor pin
HC_SR501 = Pin(SENSOR_PIN, Pin.IN)


led = Pin(15, Pin.OUT)

# Initialize state variables
motion_state = 0
prev_motion_state = 0

# Main loop
while True:
    prev_motion_state = motion_state  # Store the previous state
    motion_state = HC_SR501.value()  # Read the current state from the motion sensor
    if motion_state ==1:
        led.on()
    # Check for motion detection (transition from LOW to HIGH)
        if prev_motion_state == 0:
            print("Motion detected!")
            prev_motion_state == 1
            utime.sleep(2)  # Sleep for 2 seconds
        
        # Optional: Additional actions when motion is detected

    # Check for motion cessation (transition from HIGH to LOW)
    elif motion_state == 0:
        led.off()
        if prev_motion_state == 1:
            print("Motion stopped!") 
            prev_motion_state == 0
            utime.sleep(2) 
            # # Sleep for 2 seconds
       
    print(motion_state)